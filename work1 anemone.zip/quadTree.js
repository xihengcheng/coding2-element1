/*
Credit to Daniel Schiffman's tutorial on quadtree https://www.youtube.com/watch?v=z0YFFg_nBjw&t=904s&ab_channel=TheCodingTrain
and Ernst Schmidt's quadtree implementation https://www.ernst-schmidt.com/about
more info on quadtree check the wiki https://en.wikipedia.org/wiki/Quadtree
*/

class QuadTree {
  constructor(boundary, n) {
    this.boundary = boundary;
    this.capacity = n;
    this.movels = [];
    this.divided = false;
  }

  clear(){
    this.divided = false;
    this.movels = [];
  }

  insert(movel) {
    if (!this.boundary.contains(movel)) { //if particle is not within boundary exit
      return false;
    }

    if (this.divided) { //if boundary is already divided
      if (this.topLeft.insert(movel)) { //check all child if contain object
        return true;
      } else if (this.topRight.insert(movel)) {
        return true;
      } else if (this.botLeft.insert(movel)) {
        return true;
      } else if (this.botRight.insert(movel)) {
        return true;
      }
    }
    else if (!this.divided) { //if boundary is not divided and boundary contain particle
      this.movels.push(movel); //add particle to boundary list
      if (this.movels.length > this.capacity) { //if list exceed capacity, run subdivide
        this.subdivide();

        for (let m of this.movels) {
          if (this.topLeft.insert(m)) {
            continue;
          } else if (this.topRight.insert(m)) {
            continue;
          } else if (this.botLeft.insert(m)) {
            continue;
          } else if (this.botRight.insert(m)) {
            continue;
          }
        }
        this.movels = [];
        return true;
      }
    }
  }

  subdivide() {
    let x = this.boundary.x;
    let y = this.boundary.y;
    let w = this.boundary.w;
    let h = this.boundary.h;

    // rectMode is center
    //create 4 new quadtree child object based on current
    let rectTL = new Rectangle(x - w / 4, y - h / 4, w / 2, h / 2);
    this.topLeft = new QuadTree(rectTL, this.capacity);

    let rectTR = new Rectangle(x + w / 4, y - h / 4, w / 2, h / 2);
    this.topRight = new QuadTree(rectTR, this.capacity);

    let rectBL = new Rectangle(x - w / 4, y + h / 4, w / 2, h / 2);
    this.botLeft = new QuadTree(rectBL, this.capacity);

    let rectBR = new Rectangle(x + w / 4, y + h / 4, w / 2, h / 2);
    this.botRight = new QuadTree(rectBR, this.capacity);

    this.divided = true;
  }

  query(area, highlight) {
    let found = [];

    if (this.boundary.intersects(area)) { //if boundry box intesect the area
      if (this.divided) { //if it is divided
        let foundTL = this.topLeft.query(area, highlight);
        let foundTR = this.topRight.query(area, highlight);
        let foundBL = this.botLeft.query(area, highlight);
        let foundBR = this.botRight.query(area, highlight);
        found = found.concat(foundTL, foundTR, foundBL, foundBR);
      }
      else { //if bounary is not divided
        for (let m of this.movels) {
          if (area.contains(m)) { //check if particles in boundary is within area
            found.push(m);
          }
        }
      }
    }
    return found;
  }

  show() {
    if (this.divided) {
      this.topLeft.show();
      this.topRight.show();
      this.botLeft.show();
      this.botRight.show();
    }
    else {
      rectMode(CENTER);
      noFill();
      stroke(255, 150);
      strokeWeight(1);
      rect(this.boundary.x, this.boundary.y, this.boundary.w, this.boundary.h);
    }
  }
}