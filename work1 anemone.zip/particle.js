class Particle {

  constructor(x, y, r, s, c, colOffsets, health) {
    this.pos = createVector(x, y);
    this.vel = createVector(0, 0);
    this.velMax = 2;
    this.acc = createVector(0, 0);
    this.r = r; //radius
    this.s = s; 
    this.c = c; 

    //offset for mapping color to position/velocity
    this.colRoff = colOffsets[0];
    this.colGoff = colOffsets[1];
    this.colBoff = colOffsets[2];

    this.health = health; //life span
    this.decay = random(1, 2); 
    this.vision = new Circle(this.pos.x, this.pos.y, this.r); 
    this.neighbours = []; 
    this.lines = 0; //track how many lines has been linked
    
    this.sat = drawControl.saturationSliderParticle
  }

  
  
  show() {

    //color control based on gui input
    if (drawControl.particleColMode == "Velocity") { //map color to velocity
      let mapedCol = map(this.vel.magSq(), 0, pow(this.velMax, 2), 50, 240);
      this.c = color(mapedCol * this.colRoff+10,this.sat,100);   
    }

    if (drawControl.particleColMode == "Black") { //set color to black
      this.c = color(360,100,0,100);
    }
    if (drawControl.particleColMode == "White") { //set color to white
      this.c = color(360,0,100,100);
    }
    
    if(drawControl.saturationSliderParticle == "0"){
      this.c = color(360,0,100,100);
    }    
        if(drawControl.saturationSliderParticle == "10"){
      this.c = color(360,10,100,100);
    }
            if(drawControl.saturationSliderParticle == "20"){
      this.c = color(360,20,100,100);
    }
       
            if(drawControl.saturationSliderParticle == "30"){
      this.c = color(360,30,100,100);
    }
                if(drawControl.saturationSliderParticle == "40"){
      this.c = color(360,40,100,100);
    }
                    if(drawControl.saturationSliderParticle == "50"){
      this.c = color(360,50,100,100);
    }
                        if(drawControl.saturationSliderParticle == "60"){
      this.c = color(360,60,100,100);
    }
    
    
    //set alpha based on gui input, than map to current health
    let alp = map(this.health, 0, 100, 0, drawControl.alphaSliderParticle)
    this.c.setAlpha(alp);

    //draw methods based on gui input
    if (drawControl.drawingMethod == "Point") {
      stroke(this.c);
      point(this.pos.x, this.pos.y);
    }
    if (drawControl.drawingMethod == "Circle") {
      fill(this.c);
      noStroke();
      ellipse(this.pos.x, this.pos.y, this.r);
     // noFill();
    }
    if (drawControl.drawingMethod == "Rectangle") {
      fill(this.c);
      noStroke();
      rect(this.pos.x, this.pos.y, this.r, this.r);
    //  noFill();
    }
    if (drawControl.drawingMethod == "Lines") {
      let lineThresh = drawControl.lineCap;
      this.vision.update(this.pos.x, this.pos.y, this.r); //updates vision with current pos
      this.neighbours = this.detectNeighbours(qt); //update all neighbours within quadtree boundary (contain self)
      for (let p of this.neighbours) {
        //check if p is not self and p has not been linked more than threshold
        if (p != this && p.lines < lineThresh && this.lines < lineThresh) {
          stroke(this.c);
          strokeWeight(1);
          line(this.pos.x, this.pos.y, p.pos.x, p.pos.y);
          p.lines++;
          this.lines++;
        }
      }
    }
  }

  update() {
    this.vel.limit(2); //limit velocity to a maximum speed
    this.vel.add(this.acc);
    this.vel.limit(this.velMax);
    this.pos.add(this.vel);
    this.vel.mult(0.99); //add some fiction
    this.acc.mult(0); //reset acceleration
    this.lines = 0;

    //reset position if outside canvas
    if (this.pos.x > width) this.pos.x = 0;
    if (this.pos.x < 0) this.pos.x = width;
    if (this.pos.y > height) this.pos.y = 0;
    if (this.pos.y < 0) this.pos.y = height;
  }

  detectNeighbours(quadTree) {
    return quadTree.query(this.vision);
  }

  distSq(a, b) {
    //calculates the distance between two vector without sqrloot, runs faster
    let dx = b.x - a.x;
    let dy = b.y - a.y;
    return dx * dx + dy * dy;
  }

  checkCollision(arrayP) {
    //check every point in diffused tree for collision
    for (let p of arrayP) {
      if (this.distSq(this.pos, p) < this.r * this.r * 4) {
        return true;
      }
    }
  }

  applyForce(f) {
    this.acc.add(f);
  }

  seek(x, y, scl) {
    let targeDirection = p5.Vector.sub(createVector(x, y), this.pos);
    targeDirection.setMag(scl);
    this.applyForce(targeDirection);
  }

  applyTurbulance(scl) {
    let randomF = p5.Vector.random2D()
    randomF.setMag(scl);
    this.applyForce(randomF);
  }

  applyPull(scl) {
    let centralPull = p5.Vector.sub(createVector(width / 2, height / 2), this.pos);
    centralPull.setMag(scl); //calculate direction towards center and set mag
    this.applyForce(centralPull); //adds central force
  }

  applyPush(scl) {
    let centralExpend = p5.Vector.sub(this.pos, createVector(width / 2, height / 2));
    centralExpend.setMag(scl); //calculate direction away from center and set mag
    this.applyForce(centralExpend); //adds expend force
  }

  applyWind(direction, scl) {
    if (direction == 0) {
      let wind = createVector(0, -1);
      wind.setMag(scl);
      this.applyForce(wind); //top wind
    }
    if (direction == 1) {
      let wind = createVector(1, 0);
      wind.setMag(scl);
      this.applyForce(wind); //right wind
    }
    if (direction == 2) {
      let wind = createVector(0, 1);
      wind.setMag(scl);
      this.applyForce(wind); //down wind
    }
    if (direction == 3) {
      let wind = createVector(-1, 0);
      wind.setMag(scl);
      this.applyForce(wind); //left wind
    }
  }

  setSize(s) {
    this.r = s;
  }

  setColor(c) {
    this.c = c;
  }

  setColOffsets(colOffsets) {
    this.colRoff = colOffsets[0]; //offset for mapping color to position/velocity
    this.colGoff = colOffsets[1];
    this.colBoff = colOffsets[2];
  }

  getPos() {
    return this.pos.copy();
  }

  decaying() {
    this.health -= this.decay;
  }
}