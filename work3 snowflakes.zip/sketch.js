let snowflakes = [];

function setup() {
  createCanvas(windowWidth, windowHeight);
  for (let i = 0; i < 100; i++) {
    let x = random(width);
    let y = random(-height, 0);
    let size = random(5, 30);
    let velocity = createVector(random(-1, 1), random(1, 3)); // Random velocity
    let snowflake = new Snowflake(x, y, size, velocity);
    snowflakes.push(snowflake);
  }
}

function draw() {
  background(0);
  for (let flake of snowflakes) {
    flake.update();
    flake.display();
  }
}

class Snowflake {
  constructor(x, y, size, velocity) {
    this.position = createVector(x, y);
    this.size = size;
    this.velocity = velocity;
  }

  update() {
    // Apply additional vector operations
    // this.velocity.mult(0.9); // Optional: Apply damping to slow down the snowflake
    let acceleration = createVector(random(-0.05, 0.05), random(0.001, 0.01)); // Random acceleration
    this.velocity.add(acceleration); // Add acceleration to velocity

    // Update position based on velocity
    this.position.add(this.velocity);

    // Wrap around screen edges
    if (this.position.y > height + this.size) {
      this.position.y = -this.size;
    }
    if (this.position.x < 0) {
      this.position.x = width;
    }
    if (this.position.x > width) {
      this.position.x = 0;
    }
  }

  display() {
    fill(255);
    noStroke();
    ellipse(this.position.x, this.position.y, this.size, this.size);
  }
}
