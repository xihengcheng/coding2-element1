class ParticleSystem {

  constructor(n, particleRadius, particleSpeed, field, c, health) {
    this.particlePool = []; //array storing particle objects
    this.poolSize = n; //number of particles in canvas
    this.r = particleRadius; //radius or size of all particles
    this.s = particleSpeed; //place holder not used
    this.field = field;
    this.c = c; //color
    this.colOffsetScl = 2; //higher = brighter color, lower is darker
    this.colOffsets = [
      random(this.colOffsetScl), //random red off
      random(this.colOffsetScl+1), //random green off
      random(this.colOffsetScl+1) //random blue off
    ]
    this.health = health; //life span of all particles
    for (let i = 0; i < this.poolSize; i++) {
      this.particlePool.push(new Particle(random(width), random(height), this.r, this.s, this.c, this.colOffsets, this.health));
    }
  }

  update(diffusedArray) {
    let generalForce = 0.1; //scale for all forces (exclude field)
    for (let i = this.particlePool.length - 1; i >= 0; i--) {
      this.particlePool[i].update();

      //particle life span control
      if (drawControl.particleDecay) { //decay and kill aged particle
        this.particlePool[i].decaying(); //decrease health of particle
        if (this.particlePool[i].health <= 0) this.particlePool.splice(i, 1); //kill particle if health is 0
      }

      //general force
this.particlePool[i].applyTurbulance(0.05); //applie turbulance


      //apply force from field

        let p = this.particlePool[i].getPos();
        this.particlePool[i].applyForce(this.field.getVector(p));


      //map arrow key to a wind force
      if (keyIsPressed) {
        if (keyIsDown(UP_ARROW)) this.particlePool[i].applyWind(0, generalForce);
        if (keyIsDown(RIGHT_ARROW)) this.particlePool[i].applyWind(1, generalForce);
        if (keyIsDown(DOWN_ARROW)) this.particlePool[i].applyWind(2, generalForce);
        if (keyIsDown(LEFT_ARROW)) this.particlePool[i].applyWind(3, generalForce);
      }

      this.particlePool[i].setSize(drawControl.particleSize); //set size of particle

      //follow mouse if pressed
      if (mouseIsPressed && mouseY < height && mouseX < width && mouseButton == LEFT) {
        this.particlePool[i].seek(mouseX, mouseY, 0.15);
      }

      this.particlePool[i].show();
    }
  }

  quadTreeInsert(quadTree) {
    //inserts every particle into quadtree boundaries
    for (let p of this.particlePool) {
      quadTree.insert(p);
    }
  }

  poolSizeControl() {
    //delete particles if higher than threshold
    if (this.particlePool.length > this.poolSize) {
      let diff = abs(this.poolSize - this.particlePool.length); //calculate difference between target and current pool
      let num = map(diff, 0, 500, 0, 20); //if difference is high, delete more particles
      for (let i = 0; i < num; i++) {
        this.particlePool.splice(0, 1);
      }
    }

    //add particles if lower than threshold
    if (this.particlePool.length < this.poolSize) {
      let diff = abs(this.poolSize - this.particlePool.length);
      let num = map(diff, 0, 500, 0, 20);

      //add new particles randomly on canvas
      if (drawControl.particleSpawn == "Random") {
        for (let i = 0; i < num; i++) {
          this.particlePool.push(new Particle(random(width), random(height), this.r, this.s, this.c, this.colOffsets, this.health));
        }
      }

      //add particles in a center square
      if (drawControl.particleSpawn == "Center") {
        let gap = 20; //size of the center square
        for (let i = 0; i < num; i++) {
          this.particlePool.push(new Particle(random(width / 2 - gap, width / 2 + gap), random(height / 2 - gap, height / 2 + gap), this.r, this.s, this.c, this.colOffsets, this.health));
        }
      }

      //add particles from side of canvas
      if (drawControl.particleSpawn == "Side") {
        for (let i = 0; i < num; i++) {
          let side = floor(random(4));
          if (side == 0) this.particlePool.push(new Particle(random(width), 0, this.r, this.s, this.c, this.colOffsets, this.health)); //top
          if (side == 1) this.particlePool.push(new Particle(width, random(height), this.r, this.s, this.c, this.colOffsets, this.health)); //right
          if (side == 2) this.particlePool.push(new Particle(random(width), height, this.r, this.s, this.c, this.colOffsets, this.health)); //bottom
          if (side == 3) this.particlePool.push(new Particle(0, random(height), this.r, this.s, this.c, this.colOffsets, this.health)); //left
        }
      }

      //add particles in a cross
      if (drawControl.particleSpawn == "Cross") {
        let gap = 10;
        for (let i = 0; i < num; i++) {
          this.particlePool.push(new Particle(random(width / 2 - gap, width / 2 + gap), random(height), this.r, this.s, this.c, this.colOffsets, this.health));
          this.particlePool.push(new Particle(random(width), random(height / 2 - gap, height / 2 + gap), this.r, this.s, this.c, this.colOffsets, this.health));
        }
      }
    }
  }

  randomizeCol() {
    //create a new random col offset value
    this.colOffsets = [
      random(this.colOffsetScl),
      random(this.colOffsetScl+1),
      random(this.colOffsetScl+1)
    ]
    for (let p of this.particlePool) p.setColOffsets(this.colOffsets);
  }

  setPoolSize(num) {
    this.poolSize = num;
  }

  setHealth(h) {
    //set initial health amount of new particles
    this.health = h;
  }
}