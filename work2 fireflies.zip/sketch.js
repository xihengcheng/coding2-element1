// The Nature of Code
// Daniel Shiffman
// http://natureofcode.com

// Demonstration of Craig Reynolds' "Flocking" behavior
// See: http://www.red3d.com/cwr/
// Rules: Cohesion, Separation, Alignment

// Click mouse to add boids into the system

let flock;
let grasses = [];
let numGrassBlades = 5;

function setup() {
  createCanvas(800, 800);
  flock = new Flock();
  // Add an initial set of boids into the system
  for (let i = 0; i < 120; i++) {
    let boid = new Boid(width / 2, height / 2);
    flock.addBoid(boid);
  }
}

function draw() {
  background(0);
  flock.run();
  for (let grass of grasses){
    grass.display();
  }
  
  let t = 0;
  
for(i = grasses.length - 1; i >= 0; i--){
  let grass = grasses[i];
  for(j = flock.boids.length - 1; j >= 0; j--){
    let boid = flock.boids[j];
    if (boid && boid.position && grass && grass.x && grass.y){
      let d = dist(grass.x, grass.y, boid.position.x, boid.position.y);
  if(d < 15){
    //boid.r = 0;
    flock.boids[j].stop();
    //flock.boids[j].position = (20, 20);
    //flock.boids.splice(j, 1); // 删除相交的鸟
   t += 1;
    if(t >= 3){
      grass.light();
    }
  }
    }
  }
}

}

// Add a new boid into the System
function mouseDragged() {
  //flock.addBoid(new Boid(mouseX, mouseY));

}

function mouseClicked(){
  let newGrass = new Grass(mouseX, mouseY);
  grasses.push(newGrass);
  
}


