class Circle {
  constructor(x, y, r) {
    this.x = x;
    this.y = y;
    this.r = r;
  }

  update(x, y, r) {
    this.x = x;
    this.y = y;
    this.r = r;
  }

  contains(movel) {
    let distX = this.x - movel.pos.x;
    let distY = this.y - movel.pos.y;
    let dist = sqrt((distX * distX) + (distY * distY));
    if (dist < this.r) {
      return true;
    }
    return false;
  }

  display() {
    stroke(0, 255, 0);
    noFill();
    strokeWeight(1);
    circle(this.x, this.y, 2 * this.r);
  }
}