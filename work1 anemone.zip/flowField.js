class FlowField {
  constructor(resolution) {
    this.resolution = resolution; //resolution of vector field
    this.cols = floor(width / this.resolution); //calculate rows and cols
    this.rows = floor(height / this.resolution);
    this.vectorLst = creatGrid(this.cols, this.rows); //creat a 2D array for vectors

    this.inc = 0.05; //scale of noise field, higher num = less smooth
    this.ang = 1; //set the dynamic of flowfield
    this.mag = 0.5; //set magnitude of vector force

    this.c = color(255, 0, 0);
    this.beginOffset = random(0, 1000); //offset the start of perlin noise
    this.zoff = 0; //controls change of z over time

    let xoff = this.beginOffset;
    for (let ix = 0; ix < this.vectorLst.length; ix++) {
      let yoff = this.beginOffset;
      for (let iy = 0; iy < this.vectorLst[0].length; iy++) {
        let vectorAng = noise(xoff, yoff, this.zoff) * TWO_PI * this.ang; //set vector angle based on noise
        let vec = p5.Vector.fromAngle(vectorAng); //creat new vector with angle
        vec.setMag(this.mag); //set defult magnitude
        this.vectorLst[ix][iy] = vec;
        yoff += this.inc;
      }
      xoff += this.inc;
    }
  }

  update(zInterval) {
    //use different methode based on gui choice
this.perlin(zInterval);
  }

  perlin(zInterval) {
    let xoff = this.beginOffset;
    for (let ix = 0; ix < this.vectorLst.length; ix++) {
      let yoff = this.beginOffset;
      for (let iy = 0; iy < this.vectorLst[0].length; iy++) {
        let vectorAng = noise(xoff, yoff, this.zoff) * TWO_PI * this.ang; //set vector angle based on noise
        let vec = p5.Vector.fromAngle(vectorAng); //creat new vector with angle
        vec.setMag(this.mag);
        this.vectorLst[ix][iy] = vec;
        yoff += this.inc;
      }
      xoff += this.inc;
    }
    this.zoff += zInterval;
  }

  getVector(tempPos) {
    //receive a position vector and return the vector located at location
    let ix = constrain(floor(tempPos.x / this.resolution), 0, this.cols - 1);
    let iy = constrain(floor(tempPos.y / this.resolution), 0, this.rows - 1);
    return this.vectorLst[ix][iy].copy();
  }

  setInc(tempInc) {
    this.inc = tempInc;
  }

  setMags(tempMag) {
    this.mag = tempMag;
  }

  setDyn(tempAng) {
    this.ang = tempAng;
  }
}

function creatGrid(cols, rows) {
  //creat grid of 2D array
  let arr = new Array(cols);
  for (let i = 0; i < arr.length; i++) {
    arr[i] = new Array(rows);
  }
  return arr;
}