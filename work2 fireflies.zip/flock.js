// The Nature of Code
// Daniel Shiffman
// http://natureofcode.com

// Flock object
// Does very little, simply manages the array of all the boids

class Flock {

  constructor() {
    // An array for all the boids
    this.boids = []; // Initialize the array
    
    // create max speed slider, bind "this" context, set max speed
    this.maxSpeedSlider = createSlider(0.05, 15, 3, 0.1);
    this.onMaxSpeedSliderChange = this.onMaxSpeedSliderChange.bind(this);
    this.maxSpeedSlider.input(this.onMaxSpeedSliderChange);
    
    
    // TODO: take a look at the max and min values for all these sliders 
    
    // create seperation slider, bind "this" context
    this.seperationSlider = createSlider(0, 5, 1.5, 0.01);
    this.onSeprationSliderChange = this.onSeprationSliderChange.bind(this);
    this.seperationSlider.input(this.onSeprationSliderChange);
    
    // create max speed slider, bind "this" context, set max speed
    this.alignmentSlider = createSlider(0, 5, 1, 0.01);
    this.onAlignmentSliderChange = this.onAlignmentSliderChange.bind(this);
    this.alignmentSlider.input(this.onAlignmentSliderChange);
    
    // create max speed slider, bind "this" context, set max speed
    this.cohesionSlider = createSlider(0, 5, 1, 0.01);
    this.onCohesionSliderChange = this.onCohesionSliderChange.bind(this);
    this.cohesionSlider.input(this.onCohesionSliderChange);
    
  }
  
  onMaxSpeedSliderChange() {
    const maxSpeed = this.maxSpeedSlider.value();
    
    this.boids.forEach(function (boid) {
      boid.setMaxSpeed(maxSpeed)
    });
  }
  
  onSeprationSliderChange() {
    // todo: set all boid seperation values
    // ???
  }
  
  onAlignmentSliderChange() {
    // todo: set all boid alignment values
    // ???
  }
  
  onCohesionSliderChange() {
   // todo: set all boid cohesion values
   // ???
  }

  run() {
    for (let boid of this.boids) {
      boid.run(this.boids); // Passing the entire list of boids to each boid individually
    }
  }

  addBoid(b) {
    this.boids.push(b);
  }
}