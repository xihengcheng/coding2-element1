class Rectangle {
  constructor(x, y, w, h) {
    // X and Y define the Center!!!
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
  }

  contains(element){
     return(element.pos.x >= this.x - this.w/2 &&
            element.pos.x <= this.x + this.w/2 &&
            element.pos.y >= this.y - this.h/2 &&
            element.pos.y <= this.y + this.h/2)
  }

  intersects(circ){
    // collision detection: http://jeffreythompson.org/collision-detection/circle-rect.php

    let testX = circ.x;
    let testY = circ.y;
    if(circ.x < this.x-this.w/2)    testX = this.x-this.w/2;  // left edge
    else if(circ.x > this.x+this.w/2)  testX = this.x+this.w/2;  // right edge
    if(circ.y < this.y-this.h/2)    testY = this.y -this.h/2;  // top edge
    else if (circ.y > this.y+this.h/2)    testY = this.y + this.h/2;  // bottom edge

    let distX = circ.x - testX;
    let distY = circ.y - testY;
    let dist = sqrt((distX*distX) + (distY*distY));

    if(dist <= circ.r){
      return true;
    }
    return false;
  }
}