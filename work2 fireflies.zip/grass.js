class Grass {
  constructor(x, y) {
    // 起始位置随机，高度固定
    this.x = x;
    this.y = y;
    // 草叶的长度
    this.length = random(30, 80);
    // 草叶的摆动幅度
    this.amplitude = random(10, 50);
    // 草叶的摆动速度
    this.speed = random(0.05, 0.2);
    // 草叶的角度
    this.angle = random(TWO_PI);
  }

  // 更新草叶位置
  update() {
    // 根据速度更新角度
    this.angle += this.speed;
  }

  // 绘制草叶
  display() {

    // 计算草叶的终点位置
    let xEnd = this.x + this.amplitude * sin(this.angle);
    let yEnd = this.y - this.length;
    // 绘制草叶
    stroke(0, 150, 0); // 绿色
    strokeWeight(2);
  for(let i = 0; i < 5; i++){

        xEnd = xEnd + random(-20, 20);
        yEnd = yEnd - random(-10, 10);
    //circle(this.x, this.y, 10);
        line(this.x, this.y, xEnd, yEnd);
  }
      
  }
  
  light(){
    noStroke();
    // 设置半透明的黄色填充颜色
  fill(255, 255, 0, 7); // RGBA格式，最后一个参数150表示透明度
    circle(this.x, this.y, 100);
  }
 
}