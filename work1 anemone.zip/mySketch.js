let paused = false;
let instruction = true;
let colorB; //color of background
let colorSet = [ '#001121', '#f7f8ff', '#8c44eb'];
let diffusion = [];
let field; //stores vector field
let particles; //particle system object
let poolSize = 500; //howmany particles are in canvas
let qt; //quadtree object for particle

let enemies = [];
let a = 0;
let b = 80;
let v = 0;



var drawControl = { //control variable for all
  clearCanvas : false,
  backGroundColSliderValue: 12, // Default slider value
  backGroundColSliderMin: 0, // Slider minimum value
  backGroundColSliderMax: 255, // Slider maximum value
  particleColMode : ["Velocity", "Black", "White"], //change how color is mapped
  drawingMethod : ["Circle","Lines", "Rectangle",  "Point"], //diffent method to draw the particle
  particleCount : 600,
  particleCountMax : 5000,
  particleDecay : false,
  particleDecayRate : 250,
  particleDecayRateMin : 30,
  particleDecayRateMax : 800,
  particleSpawn : ["Side", "Center", "Cross", "Random"], //set spawn location of new particles
  particleSize : 20,
  particleSizeMin : 1,
  alphaSliderParticle : 200,
  alphaSliderParticleMin : 0,
  alphaSliderParticleMax : 255,
  saturationSliderParticle:70,
  saturationSliderParticleMin:0,
  saturationSliderParticleMax:100,
}


function setup() {
  createCanvas(800, 800);
  colorB = color(colorSet[0]);
  background(colorB);
  ellipseMode(CENTER);
  rectMode(CENTER);
  colorMode(HSB,360,100,100,100);

  for (let i = 0; i < 50; i++){
    //create the enemy
     let enemy = {
     x: random (20, width-20),
     y: random (20,height-20),
     color: "white" 
     }
     enemies.push(enemy)
    }  

  //quadtree
  let boundary = new Rectangle(width / 2, height / 2, width, height);
  qt = new QuadTree(boundary, 10);//capacity of each boundary before splitting

  //parameter: resolution of field
  field = new FlowField(20);

  //parameters: number of parciels, size of particle, placeholder, field, color, health of particles
  particles = new ParticleSystem(poolSize, drawControl.particleSize, 0, field, color(colorSet[0]), 100);

  //gui
  gui = createGui('Drawing Control'); //Creat UI
  gui.addObject(drawControl);
  gui.setPosition(810, 100); //position for UI
  
  //if(a){
     // startTime = millis(); // 记录开始时间
  //}
}


function draw() { 
  

  fill(360,0,100,100)
  
  //creating the pollution particles 0213
  if (a){
  for (let enemy of enemies){
      circle(enemy.x, enemy.y, 10) 
      enemy.color = "white" 
     }
  }
  
  
  //draw a background with alpha value
  colorB = color(colorSet[0]);
  colorB.setAlpha(drawControl.backGroundColSliderValue); // Set background color alpha based on slider value
  background(colorB);
  
  //quadtree setup
  qt.capacity = 10; //set how many particles a boundary box can contain before dividing
  qt.clear();
  particles.quadTreeInsert(qt);
  if (drawControl.showQuadTree) qt.show();
  
 // Check if particles hit enemies
for (let i = particles.particlePool.length - 1; i >= 0; i--) {
  
  let particle = particles.particlePool[i];
  for (let j = enemies.length - 1; j >= 0; j--) {
    let enemy = enemies[j];
    // Check if the particle and enemy have valid positions
    if (particle && particle.pos && enemy && enemy.x && enemy.y) {
      let d = dist(enemy.x, enemy.y, particle.pos.x, particle.pos.y);
      if (d < 15) { // Adjust the distance for collision as needed
        enemies.splice(j, 1);
        v = v + 1;
    
        if(a ){
        
        drawControl.saturationSliderParticle = b ;

  if (v > 400 && v <= 450 ) {
    b = 60; // 红色
}
            if (v > 450 && v <= 500 ) {
    b = 50; // 
}
                      if (v > 500 && v <= 550 ) {
    b = 40; 
}
                                if (v > 550 && v <= 600 ) {
    b = 30; 
}
                                          if (v > 600 && v <= 650 ) {
    b = 20; 
}
                                                    if (v > 650 && v <= 700 ) {
    b = 10; 
}
                                if (v > 700  ) {
    b = 0; 
}

          

  }
        
        
        let newEnemy = {
          x: random(20, width - 20),
          y: random(20, height-20),
          color: "white" 
        };
        enemies.push(newEnemy);
      }
    }
  }
  for (let enemy of enemies){
    enemy.color = "white";
}
} 
  //particle update here
  particles.update(diffusion, drawControl);
  particles.poolSizeControl(); //methode balances particle count
  particles.setPoolSize(drawControl.particleCount); //set particle numbers
  particles.setHealth(drawControl.particleDecayRate);

  //field controls
  //field control here
    field.update(0.01); //rate of change for field
    field.setDyn(2); //dynamics of field
    field.setMags(0.02); //controls strengh of field


  //clear canvas if toggled
  if (drawControl.clearCanvas == true) {
    colorB.setAlpha(255);
    background(colorB);
  
  }
}

function mousePressed() {
  let mousePos = createVector(mouseX, mouseY);
  let forceMagnitude = 10; // 设置力的大小
  for (let i = 0; i < particles.particlePool.length; i++) {
    let distToMouse = p5.Vector.dist(mousePos, particles.particlePool[i].pos);
    if (distToMouse < 100) { // 限制影响范围
      if (!particles.particlePool[i].ignoreMouseForce) {
      let forceDirection = p5.Vector.sub(particles.particlePool[i].pos, mousePos).normalize();
      let force = forceDirection.mult(forceMagnitude);
      particles.particlePool[i].applyForce(force);
    }
  }
}
}

function keyPressed() {
  if (key === 'p') {
    paused = !paused;
    if (paused == true) noLoop();
    else loop();
  }
  if (key === 's') save();
  if (key === 'r') particles.randomizeCol(); //randomize color gradient
  
    if (key === 'c') {
  a = 1;
  }
}



